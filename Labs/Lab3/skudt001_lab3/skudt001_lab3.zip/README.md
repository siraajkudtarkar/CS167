# Lab 3

## Student information

* Full name: Siraaj Kudtarkar
* E-mail: skudt001@ucr.edu
* UCR NetID: skudt001
* Student ID: 862129207

## Answers

- **(Q1)** Which of the following is the right way to call the `IsEven` function.

    - IsEven(5)
    - IsEven.apply(5)
    - new IsEven().apply(5)


  new IsEven().apply(5) is the right way to call the `IsEven` function.

- **(Q2)** Did the program compile?
 
No the program did not compile and gave the error:

  



- **(Q3)** If it does not work, what is the error message you get?


       java: local variables referenced from a lambda expression must be final or effectively final